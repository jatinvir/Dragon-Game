#include "potionbox.h"

PotionBox::PotionBox(int x, int y, std::string potionType)
	: x{x}, y{y}, potionType{potionType}
{}



