#ifndef STATS_H
#define STATS_H

struct Stats {
//class Stats {
//public:
    int virtual calcAtk() = 0;
    int virtual calcDef() = 0;
};

#endif
