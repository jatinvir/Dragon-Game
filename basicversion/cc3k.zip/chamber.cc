#include "chamber.h"

Chamber::Chamber(int id): id{id} {}

