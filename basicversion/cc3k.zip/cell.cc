#include "cell.h"

Cell::Cell(int x, int y, char content): x{x}, y{y}, content{content} {}
