#include "randomMoveZeroBlock.h"

void ZeroBlock::move(Cell *origin, Cell *dest, Enemy *enemy) {}
